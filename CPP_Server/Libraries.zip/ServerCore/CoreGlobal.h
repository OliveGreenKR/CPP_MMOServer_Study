#pragma once

extern class ThreadManager*			GThreadManager;
extern class MemoryManager*			GMemory;
extern class DeadLockProfiler*		GDeadLockProfiler;

